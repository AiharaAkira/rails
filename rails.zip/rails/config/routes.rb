Rails.application.routes.draw do
  	get '/' => 'home#index'
	get '/write' => 'home#write'
  	get '/add' => 'calculraor#add'	
	post '/result' => 'calculraor#result'	
	post '/create' => 'home#index'	
	get '/result/:first/:second' => 'calculraor#result'	
end
