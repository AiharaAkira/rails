class CalculraorController < ApplicationController
	
	def add
		@message = '안녕 !'
	end
	
	def result
		@result = params[:first].to_i + params[:second].to_i
	end
end
